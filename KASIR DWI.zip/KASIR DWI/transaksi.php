<?php
include 'koneksi.php';
include 'navbar.php';

if (isset($_POST['tambah'])) {
    $pelangganID = $_POST['pelanggan'];
    $tanggal = date('Y-m-d');
    $totalHarga = 0;

    mysqli_query($koneksi, "INSERT INTO penjualan (TanggalPenjualan, TotalHarga, PelangganID) VALUES ('$tanggal', '$totalHarga', '$pelangganID')");
    $penjualanID = mysqli_insert_id($koneksi);

    foreach ($_POST['produk'] as $produkID => $jumlah) {
        if ($jumlah > 0) {
            $produk = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM produk WHERE ProdukID = $produkID"));
            $subtotal = $produk['Harga'] * $jumlah;
            $totalHarga += $subtotal;

            mysqli_query($koneksi, "INSERT INTO detailpenjualan (PenjualanID, ProdukID, JumlahProduk, Subtotal) VALUES ('$penjualanID', '$produkID', '$jumlah', '$subtotal')");

            mysqli_query($koneksi, "UPDATE produk SET Stok = Stok - $jumlah WHERE ProdukID = $produkID");
        }
    }

    mysqli_query($koneksi, "UPDATE penjualan SET TotalHarga = '$totalHarga' WHERE PenjualanID = '$penjualanID'");
}

$produk = mysqli_query($koneksi, "SELECT * FROM produk");
$pelanggan = mysqli_query($koneksi, "SELECT * FROM pelanggan");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Transaksi Penjualan</title>
</head>
<body>
    <h2>Tambah Transaksi</h2>
    <form method="POST">
        <label>Pelanggan:</label>
        <select name="pelanggan">
            <?php while ($row = mysqli_fetch_assoc($pelanggan)) { ?>
                <option value="<?= $row['PelangganID'] ?>"><?= $row['NamaPelanggan'] ?></option>
            <?php } ?>
        </select><br><br>

        <h3>Pilih Produk</h3>
        <?php while ($row = mysqli_fetch_assoc($produk)) { ?>
            <label><?= $row['NamaProduk'] ?> (<?= $row['Harga'] ?>) - Stok: <?= $row['Stok'] ?></label>
            <input type="number" name="produk[<?= $row['ProdukID'] ?>]" min="0" max="<?= $row['Stok'] ?>" value="0"><br>
        <?php } ?>

        <button type="submit" name="tambah">Tambah Transaksi</button>
    </form>
</body>
</html>
