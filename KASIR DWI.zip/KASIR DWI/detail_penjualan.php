<?php
include 'koneksi.php';
include 'navbar.php';

$id = $_GET['id'];

$penjualan = mysqli_fetch_assoc(mysqli_query($koneksi, "
    SELECT penjualan.PenjualanID, TanggalPenjualan, TotalHarga, NamaPelanggan
    FROM penjualan
    JOIN pelanggan ON penjualan.PelangganID = pelanggan.PelangganID
    WHERE penjualan.PenjualanID = $id
"));

$detail_penjualan = mysqli_query($koneksi, "
    SELECT produk.NamaProduk, detailpenjualan.JumlahProduk, produk.Harga, detailpenjualan.Subtotal
    FROM detailpenjualan
    JOIN produk ON detailpenjualan.ProdukID = produk.ProdukID
    WHERE detailpenjualan.PenjualanID = $id
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Detail Penjualan</title>
</head>
<body>
    <h2>Detail Penjualan #<?= $penjualan['PenjualanID'] ?></h2>
    <p><strong>Tanggal:</strong> <?= $penjualan['TanggalPenjualan'] ?></p>
    <p><strong>Pelanggan:</strong> <?= $penjualan['NamaPelanggan'] ?></p>
    <p><strong>Total Harga:</strong> Rp<?= number_format($penjualan['TotalHarga'], 2, ',', '.') ?></p>

    <h3>Produk yang Dibeli</h3>
    <table border="1">
        <tr>
            <th>Nama Produk</th>
            <th>Jumlah</th>
            <th>Harga Satuan</th>
            <th>Subtotal</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($detail_penjualan)) { ?>
        <tr>
            <td><?= $row['NamaProduk'] ?></td>
            <td><?= $row['JumlahProduk'] ?></td>
            <td>Rp<?= number_format($row['Harga'], 2, ',', '.') ?></td>
            <td>Rp<?= number_format($row['Subtotal'], 2, ',', '.') ?></td>
        </tr>
        <?php } ?>
    </table>

    <br>
    <a href="penjualan.php">Kembali</a>
</body>
</html>
