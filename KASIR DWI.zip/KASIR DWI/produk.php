<?php
include 'koneksi.php';
include 'navbar.php';

if (isset($_POST['tambah'])) {
    $nama = $_POST['nama_produk'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $query = "INSERT INTO produk (NamaProduk, Harga, Stok) VALUES ('$nama', '$harga', '$stok')";
    mysqli_query($koneksi, $query);
}

$produk = mysqli_query($koneksi, "SELECT * FROM produk");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar Produk</title>
</head>
<body>
    <h2>Daftar Produk</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Stok</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($produk)) { ?>
        <tr>
            <td><?= $row['ProdukID'] ?></td>
            <td><?= $row['NamaProduk'] ?></td>
            <td><?= $row['Harga'] ?></td>
            <td><?= $row['Stok'] ?></td>
        </tr>
        <?php } ?>
    </table>

    <h2>Tambah Produk</h2>
    <form method="POST">
        <label>Nama Produk:</label><br>
        <input type="text" name="nama_produk" required><br>
        <label>Harga:</label><br>
        <input type="number" name="harga" required><br>
        <label>Stok:</label><br>
        <input type="number" name="stok" required><br>
        <button type="submit" name="tambah">Tambah</button>
    </form>
</body>
</html>
