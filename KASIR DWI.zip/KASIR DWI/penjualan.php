<?php
include 'koneksi.php';
include 'navbar.php';

$penjualan = mysqli_query($koneksi, "
    SELECT penjualan.PenjualanID, TanggalPenjualan, TotalHarga, NamaPelanggan
    FROM penjualan
    JOIN pelanggan ON penjualan.PelangganID = pelanggan.PelangganID
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar Penjualan</title>
</head>
<body>
    <h2>Daftar Penjualan</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Tanggal</th>
            <th>Total Harga</th>
            <th>Pelanggan</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($penjualan)) { ?>
        <tr>
            <td><?= $row['PenjualanID'] ?></td>
            <td><?= $row['TanggalPenjualan'] ?></td>
            <td>Rp<?= number_format($row['TotalHarga'], 2, ',', '.') ?></td>
            <td><?= $row['NamaPelanggan'] ?></td>
            <td>
                <a href="detail_penjualan.php?id=<?= $row['PenjualanID'] ?>">Detail</a>
            </td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>
