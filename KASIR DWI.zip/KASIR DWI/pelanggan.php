<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$password = "";
$database = "kasir_db";
include 'navbar.php';
$koneksi = mysqli_connect($host, $user, $password, $database);
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Tambah pelanggan
if (isset($_POST['tambah'])) {
    $nama = $_POST['nama_pelanggan'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['nomor_telepon'];

    $query = "INSERT INTO pelanggan (NamaPelanggan, Alamat, NomorTelepon) VALUES ('$nama', '$alamat', '$telepon')";
    mysqli_query($koneksi, $query);
    header("Location: pelanggan.php");
}

// Edit pelanggan
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama_pelanggan'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['nomor_telepon'];

    mysqli_query($koneksi, "UPDATE pelanggan SET NamaPelanggan='$nama', Alamat='$alamat', NomorTelepon='$telepon' WHERE PelangganID=$id");
    header("Location: pelanggan.php");
}

// Hapus pelanggan
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($koneksi, "DELETE FROM pelanggan WHERE PelangganID=$id");
    header("Location: pelanggan.php");
}

// Ambil daftar pelanggan
$pelanggan = mysqli_query($koneksi, "SELECT * FROM pelanggan");

// Jika mengedit pelanggan, ambil data pelanggan berdasarkan ID
$edit_pelanggan = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $edit_pelanggan = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM pelanggan WHERE PelangganID=$id"));
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manajemen Pelanggan</title>
</head>
<body>
    <h2>Daftar Pelanggan</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Nomor Telepon</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($pelanggan)) { ?>
        <tr>
            <td><?= $row['PelangganID'] ?></td>
            <td><?= $row['NamaPelanggan'] ?></td>
            <td><?= $row['Alamat'] ?></td>
            <td><?= $row['NomorTelepon'] ?></td>
            <td>
                <a href="pelanggan.php?edit=<?= $row['PelangganID'] ?>">Edit</a> |
                <a href="pelanggan.php?hapus=<?= $row['PelangganID'] ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
            </td>
        </tr>
        <?php } ?>
    </table>

    <h2><?= isset($edit_pelanggan) ? "Edit" : "Tambah" ?> Pelanggan</h2>
    <form method="POST">
        <input type="hidden" name="id" value="<?= isset($edit_pelanggan) ? $edit_pelanggan['PelangganID'] : '' ?>">
        <label>Nama Pelanggan:</label><br>
        <input type="text" name="nama_pelanggan" value="<?= isset($edit_pelanggan) ? $edit_pelanggan['NamaPelanggan'] : '' ?>" required><br>
        <label>Alamat:</label><br>
        <textarea name="alamat" required><?= isset($edit_pelanggan) ? $edit_pelanggan['Alamat'] : '' ?></textarea><br>
        <label>Nomor Telepon:</label><br>
        <input type="text" name="nomor_telepon" value="<?= isset($edit_pelanggan) ? $edit_pelanggan['NomorTelepon'] : '' ?>" required><br>
        <button type="submit" name="<?= isset($edit_pelanggan) ? "update" : "tambah" ?>">
            <?= isset($edit_pelanggan) ? "Update" : "Tambah" ?>
        </button>
    </form>
</body>
</html>
